/**
 * portal.js
 * Loads packages for MikroTik static captive portal
 *
 * This file is STATIC.
 * Values are injected during ZIP generation.
 */

/* Injected by backend during ZIP build */
const API_BASE = "{{API_BASE}}";
const LOCATION_UUID = "{{LOCATION_UUID}";

document.addEventListener("DOMContentLoaded", function () {

    // Build correct endpoint
    const endpoint = `${API_BASE}/api/portal/${LOCATION_UUID}/`;

    // Locate table
    const table = document.getElementById("packages-table");
    if (!table) {
        console.error("packages-table not found");
        return;
    }

    const tbody = table.querySelector("tbody");
    if (!tbody) {
        console.error("packages-table tbody not found");
        return;
    }

    // Fetch portal data
    fetch(endpoint, {
        method: "GET",
        headers: {
            "Accept": "application/json"
        }
    })
        .then(response => {
            if (!response.ok) {
                throw new Error("Portal API error");
            }
            return response.json();
        })
        .then(data => {

            tbody.innerHTML = "";

            if (!data.packages || data.packages.length === 0) {
                tbody.innerHTML = `
                    <tr>
                        <td colspan="2">No packages available</td>
                    </tr>
                `;
                return;
            }

            data.packages.forEach(pkg => {
                const row = document.createElement("tr");
                row.innerHTML = `
                    <td>${pkg.name}</td>
                    <td>UGX ${pkg.price}</td>
                `;
                tbody.appendChild(row);
            });
        })
        .catch(error => {
            console.error("Failed to load packages:", error);
            tbody.innerHTML = `
                <tr>
                    <td colspan="2">Unable to load packages</td>
                </tr>
            `;
        });
});
