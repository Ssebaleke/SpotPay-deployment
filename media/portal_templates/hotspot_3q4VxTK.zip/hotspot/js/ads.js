/**
 * ads.js
 * Handles loading and rotating ads on the captive portal
 *
 * This file is STATIC.
 * Dynamic values are injected during ZIP generation.
 */

/* Injected by backend during ZIP build */
const API_BASE = "{{API_BASE}}";
const LOCATION_UUID = "{{LOCATION_UUID}}";

/* DOM elements */
const adsContainer = document.getElementById("ads-container");

/* Safety check */
if (!adsContainer) {
    console.warn("Ads container not found");
}

/**
 * Fetch ads from backend
 */
async function loadAds() {
    try {
        const response = await fetch(
            `${API_BASE}/api/portal/${LOCATION_UUID}/`,
            {
                method: "GET",
                headers: {
                    "Accept": "application/json"
                }
            }
        );

        if (!response.ok) {
            throw new Error("Failed to fetch ads");
        }

        const data = await response.json();

        if (!data.ads || data.ads.length === 0) {
            console.info("No ads available");
            return;
        }

        renderAds(data.ads);

    } catch (error) {
        console.error("Ads error:", error);
    }
}

/**
 * Render ads into the page
 */
function renderAds(ads) {
    adsContainer.innerHTML = "";

    ads.forEach((ad, index) => {
        const adElement = document.createElement("div");
        adElement.className = "portal-ad";

        if (ad.type === "image") {
            const img = document.createElement("img");
            img.src = ad.url;
            img.alt = "Advertisement";
            img.loading = "lazy";
            adElement.appendChild(img);
        }

        if (ad.type === "video") {
            const video = document.createElement("video");
            video.src = ad.url;
            video.autoplay = true;
            video.muted = true;
            video.loop = true;
            video.playsInline = true;
            adElement.appendChild(video);
        }

        adsContainer.appendChild(adElement);
    });
}

/**
 * Initialize ads on page load
 */
document.addEventListener("DOMContentLoaded", () => {
    loadAds();
});
