/**
 * portal.js
 * Loads packages for MikroTik static captive portal
 *
 * This file is STATIC.
 * Values are injected during ZIP generation.
 */

/* Injected by backend during ZIP build */
const API_BASE = "{{API_BASE}}";
const LOCATION_UUID = "{{LOCATION_UUID}}";

document.addEventListener("DOMContentLoaded", function () {

    // ✅ Correct endpoint (NO double /api)
    const endpoint = `${API_BASE}/portal/${LOCATION_UUID}/`;

    // Locate packages table
    const table = document.getElementById("packages-table");
    if (!table) {
        console.log("packages-table not found");
        return;
    }

    const tbody = table.querySelector("tbody");
    if (!tbody) {
        console.log("packages-table tbody not found");
        return;
    }

    // Fetch portal data
    fetch(endpoint, {
        method: "GET",
        headers: {
            "Accept": "application/json"
        }
    })
        .then(response => {
            if (!response.ok) {
                throw new Error("Portal API error");
            }
            return response.json();
        })
        .then(data => {

            // Clear loading row
            tbody.innerHTML = "";

            if (!data.packages || data.packages.length === 0) {
                tbody.innerHTML = `
                    <tr>
                        <td colspan="2">No packages available</td>
                    </tr>
                `;
                return;
            }

            // Render packages
            data.packages.forEach(pkg => {
                const row = document.createElement("tr");
                row.innerHTML = `
                    <td>${pkg.name}</td>
                    <td>UGX ${pkg.price}</td>
                `;
                tbody.appendChild(row);
            });
        })
        .catch(error => {
            console.log("Failed to load packages:", error);

            // Fail gracefully (fallback button already visible)
            tbody.innerHTML = `
                <tr>
                    <td colspan="2">Unable to load packages</td>
                </tr>
            `;
        });
});
